import bezelHead from './bezel-head.png';
import cartIcon from './cart-icon.png';


export {bezelHead, cartIcon}
// export default function Assets(){
//     return {
//         bezelHead: bezelHead
//     }
// }